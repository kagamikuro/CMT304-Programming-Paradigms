#!/usr/bin/python3
# -*- coding: utf-8 -*-
#
# Compute Sobel gradient to images

# We use torch for this example and use example images from torchvision
import torch as t
import torchvision as tv
import numpy as np
import matplotlib.pyplot as plt

# Load example dataset (actually for machine learning, but works for this, too)
transf = tv.transforms.Compose([tv.transforms.Grayscale(), tv.transforms.ToTensor()])
imgset = tv.datasets.CIFAR10(root='./cifar10-data', train=True,
                             download=True, transform=transf)
imgloader = t.utils.data.DataLoader(imgset, batch_size=16,
                                    shuffle=True, num_workers=2)
# Get 16 random images
dataiter = iter(imgloader)
images, _ = dataiter.next()

# Sobel gradient:
# Convolution with Sobel filter
#     [[-1,0,1]
#      [-2,0,2]
#      [-1,0,1]]
# in x and y direction.
# Then take norm of x/y value per pixel.

# Sobel filter (in x - y is transposed)
sobel_x = t.autograd.Variable(t.tensor([[-1.0,0.0,1.0],[-2.0,0.0,2.0],[-1.0,0.0,1.0]]))
# Turn from 3x3 into 1x1x3x3 tensor
sobel_x.unsqueeze_(0).unsqueeze_(0)

# Apply convolution for x and y direction
g_x = t.nn.functional.conv2d(images,sobel_x)
g_y = t.nn.functional.conv2d(images,sobel_x.transpose(2,3))
# Compute norm
g = t.sqrt(t.pow(g_x,2)+t.pow(g_y,2))

# Show images and results
fig, ax = plt.subplots(4, 1, figsize=(8,8))
def imshow(imgs,ax):
    ax.imshow(np.transpose(tv.utils.make_grid(imgs).numpy(), (1, 2, 0)))
imshow(images,ax[0])
imshow(g_x,ax[1])
imshow(g_y,ax[2])
imshow(g,ax[3])
plt.show()
