#!/usr/bin/python3
# -*- coding: utf-8 -*-
#
# Simple CNN example to classify images from the Fashion-MNIST dataset
# (as part of keras.dataset examples); see https://keras.io/

# Use keras (needs tensorflow or other supported backend; GPU version highly recommended)
import keras as k
import numpy as np
import matplotlib.pyplot as plt

# Get the dataset, split in training and test set
# x is the image, y the classification
(train_x,train_y), (test_x,test_y) = k.datasets.fashion_mnist.load_data()

# Convert iamges to float and noramlise image greyscale values to 0...1
train_x = train_x.astype('float32')
test_x = test_x.astype('float32')
train_x = train_x / 255.0
test_x = test_x / 255.0

# Reshape Nx28x28 images to Nx28x28x1 tensor for N images
# (last index is channel; only one as greyscale)
train_x = train_x.reshape(-1, 28,28, 1)
test_x = test_x.reshape(-1, 28,28, 1)

# Y data in the dataset is a label from 0...9:
# Label Description  Category
# 0     T-shirt/top  0000000001
# 1     Trouser      0000000010
# 2     Pullover     0000000100
# 3     Dress        0000001000
# 4     Coat         0000010000
# 5     Sandal       0000100000
# 6     Shirt        0001000000
# 7     Sneaker      0010000000
# 8     Bag          0100000000
# 9     Ankle boot   1000000000
# We cannot use this directly for classification, but must conver it to
# a bit string, where each bit represents one class, as indicated in the
# lat column, i.e. convert it to a categorical representation.
#
train_y = k.utils.to_categorical(train_y)
test_y = k.utils.to_categorical(test_y)

# We use a sequential (simple layered) model for the CNN
model = k.models.Sequential()

# Convolutional layer with 64 3x3 filters, with ReLU and then 2x2 max-pool
model.add(k.layers.Conv2D(64, (3,3), input_shape=(28, 28, 1)))
model.add(k.layers.Activation('relu'))
model.add(k.layers.MaxPooling2D(pool_size=(2,2)))

# Repeat same layer on pooled (14x14x1) result
model.add(k.layers.Conv2D(64, (3,3)))
model.add(k.layers.Activation('relu'))
model.add(k.layers.MaxPooling2D(pool_size=(2,2)))

# Flatten output (map to vector) from previous layer (7x7x1)
# for fully connnected layer on that vector
model.add(k.layers.Flatten())
model.add(k.layers.Dense(64))

# Map 64 vector to 10 vector and use softmax for propabilties input is of specific category
model.add(k.layers.Dense(10))
model.add(k.layers.Activation('softmax'))

# Create and fit model using crossentropy loss
model.compile(loss=k.losses.categorical_crossentropy,
              optimizer=k.optimizers.Adam(),metrics=['accuracy'])
h = model.fit(train_x, train_y, batch_size=64, epochs=10,
              validation_data = (test_x, test_y))

# Evaluate model on test set
test_loss, test_acc = model.evaluate(test_x, test_y)
print('Test loss', test_loss)
print('Test accuracy', test_acc)

# Plot training history for training and validation accuracy
fig, ax = plt.subplots(2, 1, figsize=(8,8))
ax[0].plot(h.history['acc'])
ax[0].plot(h.history['val_acc'])
ax[0].set_title('Model Accuracy')
ax[0].set_ylabel('Accuracy')
ax[0].set_xlabel('Epoch')
ax[0].legend(['train', 'test'], loc='upper left')
plt.draw()
plt.pause(0.001)

# Run prediction, report result for first image and show that image
pred_y = model.predict(test_x)
print(np.argmax(np.round(pred_y[0])))
ax[1].imshow(test_x[0].reshape(28, 28), cmap = plt.cm.binary)
plt.show()
